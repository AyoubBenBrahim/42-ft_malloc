
https://github.com/lattera/freebsd/blob/master/libexec/rtld-elf/malloc.c