

![alt text](./imgs/PTEs.png "Title") 
(SOF)